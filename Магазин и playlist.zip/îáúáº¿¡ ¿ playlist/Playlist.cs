﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Магазин_и_playlist
{
    struct Song
    {
        public string Author;
        public string Title;
        public string Filename;

        public Song(string author, string title, string filename)
        {
            Author = author;
            Title = title;
            Filename = filename;
        }
        
    }

    class Playlist
    {
        public string Title
        {
            get;
            set;
        }
        public string Author
        {
            get;
            set;
        }
        public string Filename
        {
            get;
            set;
        }
        private List<Song> list;
        private int currentIndex;
        public void CreatePlayList(string Author, string Title, string Filename)
        {
            list.Add(new Song(Author, Title, Filename));
        }
        public Playlist()
        {
            list = new List<Song>();
            currentIndex = 0;
        }
        public void WriteAllPlaylist(ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (var lists in list)
            {
                //listBox.Items.Add(lists.GetInfos());
            }
        }
        public string GetInfos()
        {
            return $"Автор: {Author}; Название: {Title}; Имя файла: {Filename}";
        }
        public Song CurrentSong()
        {
            if (list.Count > 0)
                return list[currentIndex];
            else
                throw new IndexOutOfRangeException(
                    "Невозможно получить текущую аудиозапись для пустого плейлиста!");
        }

    }
}
