﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Магазин_и_playlist
{
    public partial class Form1 :Form
    {
        Shop pyaterochka;
        Playlist upload;
        int price = 0;
        int CountCola = 0;
        int CountJuice = 0;
        public Form1 ()
        {
            InitializeComponent( );
            CountCola= 168;
            CountJuice= 96;
            Product cola = new Product("Кола", 85);
            Product juice = new Product("Сок \"Добрый\"", 100);
            label1.Text = cola.GetInfo( );
            label3.Text = juice.GetInfo( );
            pyaterochka = new Shop( );
            pyaterochka.CreateProduct("Кола", 85, CountCola);
            pyaterochka.CreateProduct("Сок \"Добрый\"", 100, CountJuice);
            pyaterochka.WriteAllProducts(listBox1);
        }
        
        private void Form1_Load (object sender, EventArgs e)
        {
                        
        }

        private void toolStripLabel1_Click (object sender, EventArgs e)
        {
            listBox1.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            button1.Visible = true;
            button2.Visible = true;
            checkBox1.Visible = true;
            checkBox2.Visible = true;
            listBox2.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
        }

        private void label1_Click (object sender, EventArgs e)
        {

        }       

        private void button2_Click (object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged (object sender, EventArgs e)
        {

        }

        private void button1_Click (object sender, EventArgs e)
        {
            if(numericUpDown1.Value<CountCola&&numericUpDown2.Value<CountJuice)
            {
                if (checkBox1.Checked == true && checkBox2.Checked == true && numericUpDown1.Value > 0 && numericUpDown2.Value > 0)
                {
                    pyaterochka.Sell("Кола", Convert.ToInt32(numericUpDown1.Value));
                    pyaterochka.Sell("Сок \"Добрый\"", Convert.ToInt32(numericUpDown2.Value));
                    pyaterochka.WriteAllProducts(listBox1);
                    price = price + 85 + 100;
                    label4.Text = $"Прибыль:{price}";
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == false && numericUpDown1.Value > 0)
                {
                    pyaterochka.Sell("Кола", Convert.ToInt32(numericUpDown1.Value));
                    pyaterochka.WriteAllProducts(listBox1);
                    price = price + 85;
                    label4.Text = $"Прибыль:{price}";
                }
                else if (checkBox1.Checked == false && checkBox2.Checked == true && numericUpDown2.Value > 0)
                {
                    pyaterochka.Sell("Сок \"Добрый\"", Convert.ToInt32(numericUpDown2.Value));
                    pyaterochka.WriteAllProducts(listBox1);
                    price = price + 100;
                    label4.Text = $"Прибыль:{price}";
                }
                else
                {
                    label4.Text = $"Прибыль:{price}";
                }
            }
            else
            {
                MessageBox.Show("Лимит товаров превышен!");
            }
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Visible = true;
            if(checkBox1.Checked==false) {
                numericUpDown1.Visible = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown2.Visible = true;
            if (checkBox2.Checked == false)
            {
                numericUpDown2.Visible = false;
            }
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            checkBox1.Visible = false;
            checkBox2.Visible = false;
            listBox2.Visible = true;
            button2.Visible=true;
            button3.Visible=true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            upload = new Playlist();

            Song MyList=new Song();
            MyList.Author=textBox1.Text;
            MyList.Title=textBox2.Text;
            MyList.Filename=textBox3.Text;
            upload.CreatePlayList(textBox1.Text, textBox2.Text, textBox3.Text);
            upload.WriteAllPlaylist(listBox2);
        }
    }
}
